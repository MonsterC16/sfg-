<?php

$METRI_TOKEN = "1698002745:AAEwhRLDdfDDVtSQHQTu8aNOF-LNoaH3xMQ";

$chat_id = "1182120293";

$reload = '3';

?>